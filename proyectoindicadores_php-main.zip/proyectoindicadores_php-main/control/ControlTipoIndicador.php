<?php
class ControlTipoIndicador{
        var $objTipoIndicador;

        function __construct($objTipoIndicador){
            $this->objTipoIndicador=$objTipoIndicador;
        }

        function listar(){
            

        }




}





?>