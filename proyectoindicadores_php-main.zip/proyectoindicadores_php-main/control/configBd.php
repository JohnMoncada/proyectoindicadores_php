<?php
// credenciales, donde estan definidas variables globales 
$GLOBALS['serv']="localhost";
$GLOBALS['usua']="root";
$GLOBALS['pass']="";
$GLOBALS['bdat']="bd_indicadores";
$GLOBALS['port']=3306;
//$GLOBALS['serv']="serv1mysql.mysql.database.azure.com";
//$GLOBALS['usua']="adminmysql@serv1mysql";
//$GLOBALS['pass']="***********";
//$GLOBALS['bdat']="dbclientes";
?>